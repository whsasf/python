#!/usr/bin/env python3

from modules.sendmails import send_mail

recepients = ['xx1 <xx1+b@openwave.com>','xx3 <b--xx3@openwave.com>']
send_mail('10.49.58.239',20025,'xx2@openwave.com',recepients)